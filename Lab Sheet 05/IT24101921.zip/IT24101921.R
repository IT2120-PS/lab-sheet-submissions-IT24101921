setwd("C:\\Users\\USER\\OneDrive\\Desktop\\Lab05_PS")
getwd()

##Import the data set
data<-read.table("Data.txt",header=TRUE,sep = ",")

##View the file in separate window
fix(data)
#Close the data window before you run the rest of the commands.
#Unless rest of the commands won't run

##Attach the file into R.
attach(data)

##Parti
##Rename the variables
names(data)<-c("X1","X2")

##Attach the file in R again as we renamed the variables
attach(data)

##Obtain histogram for number of shareholders
hist(X2,main="Histogram for Number of Shareholders")

##Part 2
##Using "breaks" command we can define number of classes we need in the histogram
##along with lower limit and upper limit.
##Using "right" command we can define whether classes have closed intervals or open intervals.
histogram<-hist(X2,main="Histogram for Number of Shareholders",breaks = seq(130, 270,length = 8),right = FALSE)
 
##Check how each argument inside "hist" command works using "help" command as follows
?hist

##Part 3
##Assign class limits of the frequency distribution into a variable called "breaks"
breaks <- round(histogram$breaks)
##Assign class frequencies of the histogrm into a variable called "freq"
freq <- histogram$counts
##Assign mid point of each class into avariable called "mids"
mids <- histogram$mids

##Creating a variable called "Classes" for the frequency distribution
classes <- c()

##Creating a "for" loop to assign classes of the frequency distribution into "classes" variable crated above.
for(i in 1:length(breaks)-1){
  classes[i] <- paste0("[", breaks[i+1], ")")
} 
##Obtaining frequency distribution by combining the values of "Classes" & "freq" variables.
##"cbind" command used to merge the columns with same length
cbind(classes = classes, frequency = freq)


##Part 4
##Draw frequency polygon to the same plot
lines(mids, freq, type = "l", col = "blue")
##Draw frequency polygon in anew plot
plot(mids,freq,type = "1",main = "Frequency polygon for shareholders",xlab = "Shareholders", ylab = "Frequency", ylim = c(0,max(freq)))


## Part 4
## Draw frequency polygon to the same plot
lines(mids, freq, type = "l")

## Draw frequency polygon in a new plot
plot(mids, freq, type = "l",main = "Frequency polygon for shareholders",xlab = "Shareholders",ylab = "Frequency",ylim = c(0, max(freq)))

## Part 5
## Using "cumsum" command we can get cumulative frequencies
cum.freq <- cumsum(freq)

## Creating a null variable called "new"
new <- c()

## Using "for" loop to store cumulative frequencies in order to get the ogive
for(i in 1:length(breaks)){
  if(i == 1){
    new[i] <- 0
  } else {
    new[i] <- cum.freq[i-1]
  }
}

## Draw cumulative frequency polygon in a new plot
plot(breaks, new, type = "l",
     main = "Cumulative Frequency Polygon for Shareholders",
     xlab = "Shareholders",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))

## Obtain upper limit of each class along with its cumulative frequency in a table
cbind(Upper = breaks, CumFreq = new)




setwd("C:\\Users\\USER\\OneDrive\\Desktop\\Lab05_PS")
getwd()

##Exercise
##Part 1
Delivery.Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = "")

##view the file in separate window
fix(Delivery.Times)

##attach file into R
attach(Delivery.Times)

names(Delivery.Times) <- c("DeliveryTime")
attach(Delivery.Times)

## Part 2 – Draw histogram for delivery times
## Define class intervals (9 classes from 20 to 70, right open)
histogram <- hist(DeliveryTime,
                  main = "Histogram for Delivery Times",
                  xlab = "Delivery Time (minutes)",
                  ylab = "Frequency",
                  breaks = seq(20, 70, length = 10),
                  right = FALSE)

##Part 3
#The distribution appears to be approximately unimodal and roughly symmetric with a slight right skew 


## Part 4 – Draw Cumulative Frequency Polygon (Ogive)
## Obtain class limits and frequencies from histogram
breaks <- histogram$breaks
freq   <- histogram$counts

## Calculate cumulative frequencies
cum.freq <- cumsum(freq)

## Create a vector including 0 at the beginning
cum.freq <- c(0, cum.freq)

## Draw ogive
plot(breaks, cum.freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "red", pch = 16)


## Display upper class limits with cumulative frequencies in a table
cbind(Upper = breaks, CumulativeFrequency = cum.freq)